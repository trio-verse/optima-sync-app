import 'package:get/get_utils/get_utils.dart';

validInput(String val, int min, int max, String type) {
  if (type == "username") {
    if (!GetUtils.isUsername(val)) {
      return "39".tr;
    }
  }
  if (type == "email") {
    if (!GetUtils.isEmail(val)) {
      return "not valid email";
    }
  }
  if (type == "phone") {
    if (!GetUtils.isPhoneNumber(val)) {
      return "41".tr;
    }
  }
  if (val.isEmpty) {
    return "42".tr;
  }

  if (val.length < min) {
    return "43".trParams({"min": min.toString()});
  }
  if (val.length > max) {
    return "44".trParams({"max": max.toString()});
  }
}
