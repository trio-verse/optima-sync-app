import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';

Future<bool> get alertExitApp {
  Get.defaultDialog(
    title: "45".tr,
    middleText: "46".tr,

    actions: [
      ElevatedButton(
        onPressed: () {
          exit(0);
        },
        child: Text("47"),
      ),
      ElevatedButton(
        onPressed: () {
          Get.back();
        },
        child: Text("48"),
      ),
    ],
  );
  return Future.value(true);
}

// import 'dart:io';

// import 'package:flutter/material.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:get/get_navigation/src/extension_navigation.dart';

// Future<bool> alertExitApp() async {
//    await Get.defaultDialog<bool>(
//     title: "Exit App",
//     middleText: "Are you sure you want to exit the app?",
//     actions: [
//       ElevatedButton(
//         onPressed: () {
//           exit(0);
//         },
//         child: const Text("Confirm"),
//       ),
//       ElevatedButton(
//         onPressed: () {
//           Get.back(result: false);
//         },
//         child: const Text("Cancel"),
//       ),
//     ],
//   );
//   return  false;
// }
