import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:optima_sync_v2/app/domain/usecases/verify_code_usecase.dart';
import '../../domain/usecases/sign_up_usecase.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final SignUpUseCase signUpUseCase;
  final VerifyCodeUseCase verifyCodeUseCase;

  AuthBloc({required this.signUpUseCase, required this.verifyCodeUseCase})
    : super(AuthInitial()) {
    on<SignUpSubmitted>(_onSignUp);

    on<VerifyCodeSubmitted>(_onVerifyCode);
  }

  Future<void> _onSignUp(SignUpSubmitted event, Emitter<AuthState> emit) async {
    emit(AuthLoading());

    try {
      await signUpUseCase.execute(event.email);

      emit(SignUpSuccess(email: event.email));
    } catch (e) {
      emit(AuthFailure(message: e.toString()));
    }
  }

  Future<void> _onVerifyCode(
    VerifyCodeSubmitted event,
    Emitter<AuthState> emit,
  ) async {
    emit(AuthLoading());

    try {
      await verifyCodeUseCase.execute(email: event.email, code: event.code);

      emit(VerifySuccess());
    } catch (e) {
      emit(AuthFailure(message: e.toString()));
    }
  }
}
