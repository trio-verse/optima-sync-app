bool currentUserCanApproveCost() {
  return true;
}
