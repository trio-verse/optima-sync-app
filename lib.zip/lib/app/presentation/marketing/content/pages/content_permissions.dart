bool currentUserCanApproveCost() {
  return true;
}
