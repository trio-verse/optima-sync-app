// import 'package:flutter/material.dart';
// import 'package:optima_sync_v2/app/domain/entities/marketing/analytics_entity.dart';
// import 'package:optima_sync_v2/app/presentation/marketing/analytics/bloc/analytics_bloc.dart';
// import 'package:optima_sync_v2/app/presentation/marketing/marketing_messages.dart';
// import 'package:optima_sync_v2/core/constants/appPallete.dart';
// import 'package:optima_sync_v2/core/errors/marketing/marketing_errors.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:optima_sync_v2/app/presentation/marketing/analytics/widgets/kpi_json_view.dart';

// class MarketingAnalyticsScreen extends StatefulWidget {
//   const MarketingAnalyticsScreen({super.key});

//   @override
//   State<MarketingAnalyticsScreen> createState() => _MarketingAnalyticsScreenState();
// }

// class _MarketingAnalyticsScreenState extends State<MarketingAnalyticsScreen> {
//   @override
//   void initState() {
//     super.initState();
//     context.read<AnalyticsBloc>().add(LoadMarketingDashboard());
//   }

//   Future<void> _refresh() async {
//     context.read<AnalyticsBloc>().add(LoadMarketingDashboard());
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Marketing Analytics')),
//       body: BlocBuilder<AnalyticsBloc, AnalyticsState>(
//         builder: (context, state) => state.when(
//           initial: () => _buildLoading(),
//           loading: () => _buildLoading(),
//           failure: (error) => _buildError(context, error),
//           dashboardLoaded: (dashboard, effectiveCampaigns) => _buildDashboard(dashboard, effectiveCampaigns),

//           campaignAnalyticsLoaded: (_) => const SizedBox.shrink(),
//         ),
//       ),
//     );
//   }

//   Widget _buildLoading() => const Center(child: CircularProgressIndicator());

//   Widget _buildError(BuildContext context, AnalyticsError error) {
//     return Center(
//       child: Padding(
//         padding: const EdgeInsets.all(24),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Text(
//               error.text(context),
//               textAlign: TextAlign.center,
//               style: TextStyle(color: Colors.red.shade700),
//             ),
//             const SizedBox(height: 12),
//             OutlinedButton(onPressed: _refresh, child: const Text('Retry')),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildDashboard(MarketingDashboardEntity dashboard, List<EffectiveCampaignEntity> effectiveCampaigns) {
//     return RefreshIndicator(
//       onRefresh: _refresh,
//       child: ListView(
//         padding: const EdgeInsets.all(16),
//         children: [
//           const Text('Overview', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
//           const SizedBox(height: 12),
//           KpiJsonView(data: dashboard.toMap()),
//           const SizedBox(height: 24),
//           const Text('Most Effective Campaigns', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
//           const SizedBox(height: 12),
//           if (effectiveCampaigns.isEmpty)
//             Padding(
//               padding: const EdgeInsets.symmetric(vertical: 16),
//               child: Text('No campaign data yet.', style: TextStyle(color: AppPallete.textSecondary)),
//             )
//           else
//             ...effectiveCampaigns.map((campaign) {
//               return Card(
//                 elevation: 0,
//                 margin: const EdgeInsets.only(bottom: 12),
//                 shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(16),
//                   side: BorderSide(color: AppPallete.cardBorder),
//                 ),
//                 child: Padding(
//                   padding: const EdgeInsets.all(14),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(campaign.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
//                       const SizedBox(height: 8),
//                       KpiJsonView(data: campaign.toMap()),
//                     ],
//                   ),
//                 ),
//               );
//             }),
//         ],
//       ),
//     );
//   }
// }
