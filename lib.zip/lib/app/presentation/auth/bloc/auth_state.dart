import 'package:equatable/equatable.dart';

abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object> get props => [];
}

class AuthInitial extends AuthState {}

class AuthLoading extends AuthState {}

class LoggedIn extends AuthState {}

class LoggedOut extends AuthState {}

class LogoutInProgress extends AuthState {}

class SignUpSuccess extends AuthState {
  final String email;

  const SignUpSuccess({required this.email});

  @override
  List<Object> get props => [email];
}

class VerifySuccess extends AuthState {}

class AuthFailure extends AuthState {
  final String message;

  const AuthFailure({required this.message});

  @override
  List<Object> get props => [message];
}
