import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_bloc.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_event.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_state.dart';
import 'package:optima_sync_v2/app/presentation/widget/button_auth.dart';
import 'package:optima_sync_v2/app/presentation/widget/custom_text_title_auth.dart';
import 'package:optima_sync_v2/app/presentation/widget/text_body_auth.dart';

class VerifyCode extends StatelessWidget {
  final String email;
  const VerifyCode({super.key, required this.email});

  @override
  Widget build(BuildContext context) {
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is VerifySuccess) {
          "go to create page";
        }
        if (state is AuthFailure) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.message)));
        }
      },
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color(0xffF8FAFC),
                Color.fromARGB(255, 156, 156, 158),
                Color.fromARGB(255, 117, 118, 118),
                Color.fromARGB(255, 156, 156, 158),
                Color(0xffF8FAFC),
              ],
            ),
          ),
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(horizontal: 30, vertical: 5),
          child: ListView(
            children: [
              SizedBox(height: 20),

              const CustomTextTitleAuth(text: "Verify OTP"),
              SizedBox(height: 20),
              const CustomTextBodyAuth(
                text:
                    "Now you do not need a password to access the ERP System. Just enter your email to verify your secure session.",
              ),
              const SizedBox(height: 10),

              const SizedBox(height: 15),

              OtpTextField(
                fieldWidth: 50.0,
                borderRadius: BorderRadius.all(Radius.circular(15)),
                numberOfFields: 6,
                borderColor: Color.fromARGB(255, 7, 227, 40),
                //set to true to show as box or false to show as dash
                showFieldAsBox: true,
                //runs when a code is typed in
                onCodeChanged: (String code) {
                  //handle validation or checks here
                },
                //runs when every textfield is filled
                onSubmit: (String verificationCode) {
                  context.read<AuthBloc>().add(
                    VerifyCodeSubmitted(email: email, code: verificationCode),
                  );
                }, // end onSubmit
              ),
              SizedBox(height: 20),
              const CustomTextBodyAuth(
                text: "We have sent a verification code to your email.",
              ),
              SizedBox(height: 20),
              CustomButtonAuth(text: 'Verify & Sign In', onPressed: () {}),
            ],
          ),
        ),
      ),
    );
  }
}
