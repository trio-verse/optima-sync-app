import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_bloc.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_event.dart';
import 'package:optima_sync_v2/app/presentation/screens/auth/verifiy_code_screen.dart';
import 'package:optima_sync_v2/app/presentation/widget/button_auth.dart';
import 'package:optima_sync_v2/app/presentation/widget/check_box_list_Tile.dart';
import 'package:optima_sync_v2/app/presentation/widget/text_body_auth.dart';
import 'package:optima_sync_v2/app/presentation/widget/text_form_auth.dart';
import 'package:optima_sync_v2/core/functions/alert_exit_app.dart';
import 'package:optima_sync_v2/core/functions/inputvalid.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_state.dart';

class SignUp extends StatefulWidget {
  const SignUp({super.key});

  @override
  State<SignUp> createState() => _SignUpState();
}

class _SignUpState extends State<SignUp> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();

  @override
  void dispose() {
    emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is SignUpSuccess) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => VerifyCode(email: state.email)),
          );
        }

        if (state is AuthFailure) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.message)));
        }
      },
      child: Scaffold(
        body: WillPopScope(
          onWillPop: () => alertExitApp,
          child: Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
                colors: [
                  Color(0xffF8FAFC),
                  // Color.fromARGB(255, 156, 156, 158),
                  Color.fromARGB(255, 117, 118, 118),
                  // Color.fromARGB(255, 156, 156, 158),
                  Color(0xffF8FAFC),
                ],
              ),
            ),
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Center(
                  child: Column(
                    children: [
                      const SizedBox(height: 200),

                      const Text(
                        "Sign Up",
                        style: TextStyle(
                          fontSize: 40,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 20),

                      const CustomTextBodyAuth(
                        text:
                            "Now you do not need a password to access the ERP System. Just enter your email to verify your secure session.",
                      ),

                      const SizedBox(height: 25),

                      Padding(
                        padding: const EdgeInsets.all(11),
                        child: CustomTextFormAuth(
                          mycontroller: emailController,
                          hinttext: "Enter Your Email",
                          labeltext: "Email",
                          iconData: Icons.email_outlined,
                          isNumber: false,
                          valid: (value) {
                            return validInput(value!, 3, 50, "email");
                          },
                        ),
                      ),

                      CheckBoxListTile(),

                      const SizedBox(height: 20),

                      CustomButtonAuth(
                        text: "Get Verification Code",
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            context.read<AuthBloc>().add(
                              SignUpSubmitted(
                                email: emailController.text.trim(),
                              ),
                            );
                          }
                        },
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
