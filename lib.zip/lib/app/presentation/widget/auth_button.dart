import 'package:flutter/material.dart';
import 'package:optima_sync_v2/core/theme/app_pallete.dart';

class AuthBotton extends StatelessWidget {
  const AuthBotton({super.key});

  @override
  Widget build(BuildContext context) {
    return  Container(
      // height: 50,
      // width: 50,
      decoration: BoxDecoration(
        borderRadius:BorderRadius.circular(10),
        // color: Colors.amber,
        // gradient: LinearGradient(colors: [AppPallete.authBottonColor])
      ),
      child: ElevatedButton(onPressed: (){} ,
      style: ElevatedButton.styleFrom(fixedSize: const Size(395, 55),
      backgroundColor: Colors.blue
      ),
      child:Text("Get Verification Code",style: TextStyle(fontSize: 17,
      fontWeight: FontWeight.w600),),
      ),
    );
  }
}