import 'package:flutter/material.dart';

class CustomTextBodyAuth extends StatelessWidget {
  final String? text;
  const CustomTextBodyAuth({super.key, this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Text(
        text!,
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.bodySmall,
      ),
    );
  }
}
