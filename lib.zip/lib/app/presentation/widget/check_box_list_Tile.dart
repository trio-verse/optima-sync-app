import 'package:flutter/material.dart';

class CheckBoxListTile extends StatefulWidget {

   CheckBoxListTile({super.key});

  @override
  State<CheckBoxListTile> createState() => _CheckBoxListTileState();
}

class _CheckBoxListTileState extends State<CheckBoxListTile> {

  bool _checked=false;
  @override
  Widget build(BuildContext context) {
    return CheckboxListTile(
      
      activeColor: Colors.blue,
      checkColor: Colors.black,
        controlAffinity: ListTileControlAffinity.leading,

      title: Text("By continuing, you agree to our ERP Terms of Service and Corporate Privacy Policy.",       style: Theme.of(context).textTheme.bodySmall,),

      value:_checked  , onChanged: (bool? value){
        setState(() {
          _checked= value!;
        });
      });
  }
}