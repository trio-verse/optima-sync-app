import 'package:flutter/material.dart';

class CustomTextTitleAuth extends StatelessWidget {
  final String? text;
  const CustomTextTitleAuth({super.key, this.text});

  @override
  Widget build(BuildContext context) {
    return Text(
      text!,
      textAlign: TextAlign.center,
      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
    );
  }
}
