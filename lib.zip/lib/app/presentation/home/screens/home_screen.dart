import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final addressController = TextEditingController();
  final descriptionController = TextEditingController();
  List<String> countryCode = [
    "🇦🇪 +971",
    "🇸🇦 +966",
    "🇱🇧 +961",
    "🇯🇴 +962",
    "🇸🇾 +963",
  ];
  String selectedCode = "🇯🇴 +962";
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.sizeOf(context);

    return Scaffold(
      appBar: AppBar(centerTitle: true, title: Text('Create Organisation')),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Center(
          child: Column(
            spacing: 15,
            children: [
              Text(""),
              InkWell(
                child: CircleAvatar(
                  radius: 80,

                  backgroundImage: NetworkImage("url"),
                ),
              ),
              // Container(
              //   decoration: BoxDecoration(border: .all()),
              //   child: Image(image: NetworkImage("url")),
              // ),
              Row(
                spacing: 15,
                children: [Icon(Icons.info_outline), Text("IDENTITY")],
              ),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  label: Text('Organisation Name'),
                  hint: Text('Optima Sync'),
                  suffixIcon: Icon(Icons.person_2_outlined),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1, color: Colors.blue),
                  ),
                ),
              ),
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  label: Text('Organisation Email'),
                  hint: Text('john.doe@gmail.com'),
                  suffixIcon: Icon(Icons.email),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1, color: Colors.blue),
                  ),
                ),
              ),
              Row(
                spacing: 15,
                children: [Icon(Icons.info_outline), Text("PERSENCE")],
              ),
              Center(
                child: Row(
                  spacing: 10,
                  children: [
                    SizedBox(
                      width: 100,
                      child: DropdownButton<String>(
                        value: selectedCode,

                        items: countryCode
                            .map(
                              (code) => DropdownMenuItem<String>(
                                child: Text(code),
                                value: code,
                              ),
                            )
                            .toList(),
                        onChanged: (code) {},
                      ),
                    ),
                    Expanded(
                      child: TextField(
                        controller: phoneController,
                        decoration: InputDecoration(
                          label: Text('Phone Number'),
                          hint: Text('999 999 999'),
                          suffixIcon: Icon(Icons.phone_android_outlined),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(width: 1),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              width: 1,
                              color: Colors.blue,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              TextField(
                controller: addressController,
                decoration: InputDecoration(
                  label: Text('Address'),
                  hint: Text('City , Country'),
                  suffixIcon: Icon(Icons.location_city_outlined),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1, color: Colors.blue),
                  ),
                ),
              ),
              TextField(
                controller: descriptionController,
                decoration: InputDecoration(
                  label: Text('description'),
                  hint: Text(
                    'Tell us more about your buissniss fields, branches, or operations...',
                  ),
                  suffixIcon: Icon(Icons.location_city_outlined),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(width: 1, color: Colors.blue),
                  ),
                ),
              ),

              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                onPressed: () {},
                child: Text(
                  "Create & Get Started",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
