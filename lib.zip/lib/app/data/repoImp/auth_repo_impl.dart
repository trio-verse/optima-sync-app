import 'package:optima_sync_v2/app/data/sources/remote_data/auth_remote_data_source.dart';
import 'package:optima_sync_v2/app/domain/repo/auth/auth_repo.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthRemoteDataSource remoteDataSource;

  AuthRepositoryImpl({required this.remoteDataSource});

  @override
  Future<void> signUp(String email) async {
    await remoteDataSource.signUp(email);
  }

  @override
  Future<void> verifyCode({required String email, required String code}) async {
    await remoteDataSource.verifyCode(email: email, code: code);
  }
}
