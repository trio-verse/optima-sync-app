import 'dart:convert';

import 'package:http/http.dart' as http;

class AuthRemoteDataSource {
  final http.Client client;

  AuthRemoteDataSource({required this.client});

  final String baseUrl = "https://optima.trio-verse.com";
  Future<void> signUp(String email) async {
    final response = await client.post(
      Uri.parse("$baseUrl/api/v1/register-email"),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: jsonEncode({"email": email}),
    );

    if (response.statusCode != 201) {
      throw Exception("Status Code: ${response.statusCode}\n${response.body}");
    }
  }

  Future<void> verifyCode({required String email, required String code}) async {
    final response = await client.post(
      Uri.parse("$baseUrl/api/v1/verify-otp"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"email": email, "otp": code}),
    );

    if (response.statusCode != 200) {
      throw Exception("Verification failed");
    }
  }
}
