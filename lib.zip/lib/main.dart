import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;

import 'package:optima_sync_v2/app/data/repoImp/auth_repo_impl.dart';
import 'package:optima_sync_v2/app/data/sources/remote_data/auth_remote_data_source.dart';
import 'package:optima_sync_v2/app/domain/usecases/sign_up_usecase.dart';
import 'package:optima_sync_v2/app/domain/usecases/verify_code_usecase.dart';
import 'package:optima_sync_v2/app/presentation/bloc/auth_bloc.dart';
import 'package:optima_sync_v2/app/presentation/screens/auth/signup_screen.dart';
import 'package:optima_sync_v2/core/theme/theme.dart';

void main() {
  final remoteDataSource = AuthRemoteDataSource(client: http.Client());

  final repository = AuthRepositoryImpl(remoteDataSource: remoteDataSource);

  runApp(
    BlocProvider(
      create: (_) => AuthBloc(
        signUpUseCase: SignUpUseCase(repository),
        verifyCodeUseCase: VerifyCodeUseCase(repository),
      ),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "OptimaSync1",
      theme: AppTheme.lightModeTheme,
      home: const SignUp(),
    );
  }
}
